package utilities;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;

@Component
public class JwtToken {
	
	public static final long serialVersionUID = 123456L;
	
	public static final long JWT_EXPIRATION = 100 * 60;
	
	private String secret = "json";
	
	public <T> T getUserDetailsFromToken(String token, Function<Claims, T> claims)
	
//	public String getUserName(String jwtToken) {
//		return getUserDetailsFromToken(jwtToken, Claims::getSubject);
//	}
	
	

}
