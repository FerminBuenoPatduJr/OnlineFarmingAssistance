package com.example.demo.configuration;

import javax.ws.rs.ApplicationPath;


import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;
import com.example.demo.controllers.UserController;

import utilities.CorsFilter;

@Component
@ApplicationPath("/api")
public class JerseyConfiguration extends ResourceConfig {
	
	public JerseyConfiguration() {
		register(UserController.class);
		register(CorsFilter.class);
	}
}
